This is the complete set of the castle, i have the model, the textures, the masks used
 by the textures and as an added bonus, the peices of the sky texture, enjoy!
if you use this could you give credit to Alec Pike, or at least try to remember my name?
if you have any comments or complaints or need help with the model 
or something e-mail me at alec.pike@gmail.com